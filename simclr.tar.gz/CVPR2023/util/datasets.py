# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
# --------------------------------------------------------
# References:
# DeiT: https://github.com/facebookresearch/deit
# --------------------------------------------------------

import os
import PIL
import torch
from torchvision import datasets, transforms
import torchvision
import random
from torch.utils.data import Dataset
from timm.data import create_transform
from timm.data.constants import IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD
from util.train_transform import random_rotate,ResizedRotation,WrapWithRandomParams

def build_dataset(is_train, args):
    #root = os.path.join(args.data_path, 'train' if is_train else 'val')
    #dataset = datasets.ImageFolder(root, transform=transform)
    if args.dataset == "c10":
         dataset = torchvision.datasets.CIFAR10(
        root='./data', train=is_train, download=True, transform=transform)
    elif args.dataset == "c100":
        if is_train == True:
            dataset_train = torchvision.datasets.CIFAR100(
                root='./data', train=False, download=True)
            dataset = PretrainingDatasetWrapper(dataset_train, debug=False , args=args)
        else:
            transform = build_transform_val(args)
            dataset = torchvision.datasets.CIFAR100(
                root='./data', train=False, download=True, transform=transform)
    print(dataset)
    return dataset




class PretrainingDatasetWrapper(Dataset):
    def __init__(self, ds: Dataset, debug=False ,args=None):
        super().__init__()
        self.ds = ds
        self.debug = debug
        target_size = (args.input_size , args.input_size)
        if debug:
            print("DATASET IN DEBUG MODE")
        
        
        if args.dataset == "c10":
            mean = (0.4914, 0.4822, 0.4465)
            std = (0.2023, 0.1994, 0.2010)
        elif args.dataset == "c100":
            mean = (0.5071 ,0.4865 ,0.4409)
            std = (0.2009 ,0.1984 ,0.2023)
        
        
        self.preprocess = transforms.Compose([
                    transforms.ToTensor(),
                    transforms.Normalize(mean=mean, std=std),
            ])
        
        
        random_resized_rotation = WrapWithRandomParams(lambda angle: ResizedRotation(angle, target_size), [(0.0, 360.0)])
        self.randomize = transforms.Compose([
            transforms.RandomResizedCrop(target_size, scale=(1/3, 1.0), ratio=(0.3, 2.0)),
            transforms.RandomChoice([
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.Lambda(random_rotate)
            ]),
            transforms.RandomApply([
                random_resized_rotation
            ], p=0.33),
            transforms.RandomApply([
                transforms.ColorJitter(brightness=0.5, contrast=0.5, saturation=0.5, hue=0.2)
            ], p=0.8),
            transforms.RandomGrayscale(p=0.2)
        ])
    
    def __len__(self): return len(self.ds)
    
    def __getitem_internal__(self, idx, preprocess=True):
        this_image_raw, target = self.ds[idx]
        
        if self.debug:
            random.seed(idx)
            t1 = self.randomize(this_image_raw)
            random.seed(idx + 1)
            t2 = self.randomize(this_image_raw)
        else:
            t1 = self.randomize(this_image_raw)
            t2 = self.randomize(this_image_raw)
        
        if preprocess:
            t1 = self.preprocess(t1)
            t2 = self.preprocess(t2)
        else:
            t1 = transforms.ToTensor()(t1)
            t2 = transforms.ToTensor()(t2)

        return t1, t2, torch.tensor(target)

    def __getitem__(self, idx):
        return self.__getitem_internal__(idx, True)
    
    def raw(self, idx):
        return self.__getitem_internal__(idx, False)

    



def build_transform_val(args):
    if args.dataset == "c10":
        mean = (0.4914, 0.4822, 0.4465)
        std = (0.2023, 0.1994, 0.2010)
    elif args.dataset == "c100":
        mean = (0.5071 ,0.4865 ,0.4409)
        std = (0.2009 ,0.1984 ,0.2023)

    t = []
    
    size = int(args.input_size)
    t.append(
        transforms.Resize(size, interpolation=PIL.Image.BICUBIC),  # to maintain same ratio w.r.t. 224 images
    )
    t.append(transforms.CenterCrop(args.input_size))

    t.append(transforms.ToTensor())
    t.append(transforms.Normalize(mean, std))
    return transforms.Compose(t)


